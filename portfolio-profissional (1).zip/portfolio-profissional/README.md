# Portfólio profissional

## Sobre o projeto

Portfólio profissional de Ana, estudante de Análise e Desenvolvimento de Sistemas.

## Objetivos

Apresentar formação, competências, áreas de interesse, currículo e formas de contato em uma página profissional publicada no GitHub Pages.

## Tecnologias utilizadas

- HTML5
- CSS3

## Estrutura do portfólio

```text
portfolio-profissional/
├── index.html
├── style.css
├── README.md
├── LICENSE
└── assets/
    └── curriculo.pdf
```

## Projetos apresentados

A seção de projetos está preparada para receber projetos reais futuramente.

## Evidências visuais

[INSERIR IMAGENS DOS PROJETOS APÓS ADICIONÁ-LOS]

## Como acessar

GitHub Pages:
[INSERIR LINK DO GITHUB PAGES APÓS A PUBLICAÇÃO]

## Como executar localmente

1. Baixe ou clone o repositório.
2. Abra a pasta do projeto.
3. Abra o arquivo `index.html` em um navegador.
4. Para visualizar o currículo, mantenha `curriculo.pdf` dentro da pasta `assets`.

## Autoria

Ana

Projeto desenvolvido para a disciplina **Design Profissional**.

## Licença

[LICENÇA A DEFINIR PELO AUTOR]
